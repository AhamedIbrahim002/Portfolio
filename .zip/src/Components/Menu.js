// src/Components/Menu.js
import React, { useEffect, useState } from "react";
import "./Menu.css";
import {
  FaHome, FaProjectDiagram, FaUser,
  FaGraduationCap, FaLaptopCode,
  FaBriefcase, FaFileAlt, FaCertificate
} from "react-icons/fa";
import profileImage from "../assets/Profile.jpg";

const Menu = () => {
  const [isSticky, setIsSticky] = useState(false); // This is your sidebar toggle

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 100); // Show sidebar after 100px scroll
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav className={`menu-bar ${isSticky ? "sidebar" : ""}`}>
      {/* Show profile pic only when sticky sidebar is active */}
      {isSticky && (
        <div className="sidebar-profile">
          <img src={profileImage} alt="Ahamed Ibrahim" className="sidebar-pic" />
        </div>
      )}

      <ul className="menu-list">
        <li><a href="#Home"><FaHome /> Home</a></li>
          <li><a href="#experience"><FaBriefcase /> Experience</a></li>
           <li><a href="#education"><FaGraduationCap /> Education</a></li>
        <li><a href="#projects"><FaProjectDiagram /> Projects</a></li>
         <li><a href="#skills"><FaLaptopCode /> Skills</a></li>
        <li><a href="#certifications"><FaCertificate /> Certifications</a></li>
        <li><a href="#about"><FaUser /> About</a></li>
       
       
      
        <li>
          <a
            href="/Ahamed_Ibrahim_Resume.pdf"
            download
            target="_blank"
            rel="noopener noreferrer"
          >
            <FaFileAlt /> Resume
          </a>
        </li>
        
      </ul>
    </nav>
  );
};

export default Menu;
